import React, { Component } from 'react';

const TableHead = () => {
    return (
        <thead>
            <tr>
                <th>Aluno</th>
                <th>Modalidade</th>
                <th>Preços</th>
                <th>Remover</th>
            </tr>
        </thead>
    );
}

const TableBody = props => {

    const linhas = props.aluno.map( (linha, index) => {
        return(
            <tr key={index}>
                <td>{ linha.nome }</td>
                <td>{ linha.modalidade }</td>
                <td>{ linha.preco }</td>
                <td><button onClick={ () => { props.removeAluno(index) }} className="waves-effect waves-light btn green">Remover</button></td>
            </tr>
        );
    });

    return(
        <tbody>
            {linhas}
        </tbody>
    );
}

class Tabela extends Component {

    render() {
        
        const{ aluno, removeAluno } = this.props;
        //console.log(autores);

        return (
            <table className="centered highlight">
                <TableHead />
                <TableBody aluno = { aluno } removeAluno = {removeAluno}/>
            </table>
        );
    }

}

export default Tabela;