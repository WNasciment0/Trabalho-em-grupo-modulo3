import React from 'react'

const Header = () => {

    return (
        <nav id='t1'>
            <div class="nav-wrapper">
            <a href="/Inicio" class="brand-logo">Academia AcadeForma</a>
                <ul  class="right">
                    <li><a href="/Inicio">Inicio</a></li>
                    <li><a href="http://localhost:3000/">Aluno</a></li>
                    <li><a href="/Modalidade">Modalidade</a></li>
                    <li><a href="Cadastrar">Cadastrar</a></li>
                </ul>
            </div>
        </nav>
    )
}

export default Header