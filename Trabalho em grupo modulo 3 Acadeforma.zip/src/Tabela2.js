import React, { Component } from 'react';

const TableHead = () => {
    return (
        <thead>
            <tr>
                <th>Aluno</th>
                <th>Modalidade</th>
                <th>Preços</th>
            
            </tr>
        </thead>
    );
}

const TableBody = props => {

    const linhas = props.aluno.map( (linha, index) => {
        return(
            <tr key={index}>
                <td>{ linha.nome }</td>
                <td>{ linha.modalidade }</td>
                <td>{ linha.preco }</td>
            
            </tr>
        );
    });

    return(
        <tbody>
            {linhas}
        </tbody>
    );
}

class Tabela extends Component {

    render() {
        
        
        //console.log(autores);

        return (
            <table className="centered highlight">
               
            </table>
        );
    }

}

export default Tabela;