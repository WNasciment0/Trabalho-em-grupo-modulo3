import React, { Component, Fragment } from 'react';
import 'materialize-css/dist/css/materialize.min.css';
import './App.css'
import Tabela from './Tabela.js'
import Formulario from './Formulario.js'
import Header from "./Header.js"

class App extends Component {

  state = {
    aluno: [
      {
        nome: 'Paulo',
        modalidade: 'Musculação',
        preco: '100'
      },
      {
        nome: 'Daniel',
        modalidade: 'Sppining',
        preco: '120'
      },
      {
        nome: 'Marcos',
        modalidade: 'Natação',
        preco: '150'
      },
      {
        nome: 'Bruno',
        modalidade: 'Luta',
        preco: '100'
      },
      {
        nome: 'Nico',
        modalidade: 'Hidroginastica',
        preco: '333'
      }
    ],

  };

  removeAluno = index => {

    const { aluno } = this.state;

    this.setState(
      {
        aluno: aluno.filter((aluno, posAtual) => {
          console.log(index, posAtual)
          return posAtual !== index;
        }),
      }
    );
  }

  escutadorDeSubmit = aluno => {
    this.setState({ aluno: [...this.state.aluno, aluno] })
  }

  render() {
    return (
      <Fragment>
        <Header />
        <div className="container mb-10">
          <Tabela aluno={this.state.aluno} removeAluno={this.removeAluno} />
          <Formulario escutadorDeSubmit={this.escutadorDeSubmit} />
        </div>

      </Fragment>
    );
  }

}

export default App;
