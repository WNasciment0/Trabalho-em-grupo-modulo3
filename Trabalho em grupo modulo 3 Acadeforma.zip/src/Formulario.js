import React, { Component } from 'react'

class Formulario extends Component {

    constructor(props) {
        super(props)

        this.stateInicial = {
            nome: '',
            modalidade: '',
            preco: '',
        }

        this.state = this.stateInicial
    }

    escutadorDeInput = event => {
        const { name, value } = event.target

        this.setState({
            [name]: value
        })
    }

    submitFormulario = () => {
        this.props.escutadorDeSubmit(this.state)
        this.setState(this.stateInicial)
    }

    render() {

        const { nome, modalidade, preco } = this.state

        return (
            <form>

                <div className="row">
                    <div className="input-field col s4">
                        <label className="input-field" htmlFor="nome">Nome</label>
                        <input
                            className="validate"
                            id="nome"
                            type="text"
                            name="nome"
                            value={nome}
                            onChange={this.escutadorDeInput}
                        />
                    </div>

                    <div className="input-field col s4">
                        <label className="input-field" htmlFor="modalidade">Modalidade</label>
                        <input
                            className="validate"
                            id="modalidade"
                            type="text"
                            name="modalidade"
                            value={modalidade}
                            onChange={this.escutadorDeInput}
                        />

                    </div>

                    <div className="input-field col s4">
                        <label className="input-field" htmlFor="preco">Preço</label>
                        <input
                            className="validate"
                            id="preco"
                            type="text"
                            name="preco"
                            value={preco}
                            onChange={this.escutadorDeInput}
                        />
                    </div>

                </div>




                <button type="button" onClick={this.submitFormulario} className="waves-effect waves-light btn green">Salvar</button>
            </form>
        )
    }
}

export default Formulario